# Commands to invoke SendMail and SMS 
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!Pleace visit www.mypage.net to make sure we have your eMail address
cat smtp/Alan.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Linda.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Vicki.send | sendmail -i -t
cat smtp/Robert.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!Pleace visit www.mypage.net to make sure we have your eMail address
cat smtp/Samuel.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Janice.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Denise.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!Pleace visit www.mypage.net to make sure we have your eMail address
cat smtp/Mark.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Fred.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Virginia.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Carl.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Barbara.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Jo.send | sendmail -i -t
cat smtp/David.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Bobby.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Judy.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Constance.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Bruce.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Francis.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Kathryn.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Henry.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Deborah.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Joanne.send | sendmail -i -t
cat smtp/Thomas.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Andrew.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Christine.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Sarah.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Frank.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Eddie.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Ruth.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Johnny.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Kathleen.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Sheila.send | sendmail -i -t
cat smtp/Larry.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Randall.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Beverly.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Eileen.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Timothy.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Earl.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Wanda.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Phillipe.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Donna.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Maria.send | sendmail -i -t
cat smtp/Donald.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Barry.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Catherine.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Victoria.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Wayne.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Clarence.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Jacqueline.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Jimmy.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Diane.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Lynn.send | sendmail -i -t
cat smtp/Dennis.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Leonard.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Marilyn.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Sylvia.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Patrick.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Eric.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Katherine.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Glenn.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Shirley.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Darlene.send | sendmail -i -t
cat smtp/George.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Randy.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Joan.send | sendmail -i -t
curl http://textbelt.com/text -d number{phone} -d message=Time to Renew!
cat smtp/Sue.send | sendmail -i -t