# Commands to invoke SendMail for postal customers
cat smtp/James.send | sendmail -i -t
cat smtp/Daniel.send | sendmail -i -t
cat smtp/Alan.send | sendmail -i -t
cat smtp/Harry.send | sendmail -i -t
cat smtp/Ernest.send | sendmail -i -t
cat smtp/Linda.send | sendmail -i -t
cat smtp/Judith.send | sendmail -i -t
cat smtp/Peggy.send | sendmail -i -t
cat smtp/Vicki.send | sendmail -i -t
cat smtp/Teresa.send | sendmail -i -t